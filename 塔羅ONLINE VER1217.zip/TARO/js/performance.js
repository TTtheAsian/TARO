// 性能監控
const performanceMonitor = {
    init() {
        this.measurePageLoad();
        this.measureInteractions();
    },

    measurePageLoad() {
        window.addEventListener('load', () => {
            const timing = performance.timing;
            const pageLoadTime = timing.loadEventEnd - timing.navigationStart;
            console.log(`頁面載入時間: ${pageLoadTime}ms`);
        });
    },

    measureInteractions() {
        // 監控用戶交互性能
        const observer = new PerformanceObserver((list) => {
            list.getEntries().forEach((entry) => {
                console.log(`交互延遲: ${entry.duration}ms`);
            });
        });
        observer.observe({ entryTypes: ['first-input', 'layout-shift'] });
    }
}; 