// 塔羅牌資料
const tarotCards = {
    majorArcana: [
        {
            id: 0,
            name: "愚人",
            number: 0,
            img: "CARD/225_00.jpg",
            meaning: "新的開始，冒險，自由，擁抱未知，但也需要注意風險。",
            interpretation: "當前形勢充滿可能性，建議保持開放心態，勇於嘗試新事物。"
        },
        {
            id: 1,
            name: "魔術師",
            number: 1,
            img: "CARD/225_01.jpg",
            meaning: "意志力，創造力，行動力，運用才能和資源，將想法付諸行動。",
            interpretation: "現在是實現想法的好時機，善用你的才能和資源。"
        },
        {
            id: 2,
            name: "女祭司",
            number: 2,
            img: "CARD/225_02.jpg",
            meaning: "直覺，智慧，內在指引，傾聽內心聲音，信任直覺。",
            interpretation: "傾聽你的內心聲音，相信你的直覺判斷。"
        },
        {
            id: 3,
            name: "皇后",
            number: 3,
            img: "CARD/225_03.jpg",
            meaning: "豐盛，創造力，母性，享受生命的美好，照顧自己和他人。",
            interpretation: "關注生活的豐盛面，善待自己也照顧他人。"
        },
        {
            id: 4,
            name: "皇帝",
            number: 4,
            img: "CARD/225_04.jpg",
            meaning: "權威，秩序，父性，建立穩固的基礎，設定界限。",
            interpretation: "需要建立秩序和規則，展現領導力。"
        },
        {
            id: 5,
            name: "教皇",
            number: 5,
            img: "CARD/225_05.jpg",
            meaning: "傳統，信仰，道德，教導，尋求指引和智慧。",
            interpretation: "遵循傳統智慧，或尋求精神導師的建議。"
        },
        {
            id: 6,
            name: "戀人",
            number: 6,
            img: "CARD/225_06.jpg",
            meaning: "愛，合作關係，選擇，在關係中找到平衡。",
            interpretation: "面臨重要的選擇，需要聆聽內心的聲音。"
        },
        {
            id: 7,
            name: "戰車",
            number: 7,
            img: "CARD/225_07.jpg",
            meaning: "意志力，決心，控制，克服挑戰，保持專注。",
            interpretation: "通過意志力和決心來克服困難。"
        },
        {
            id: 8,
            name: "力量",
            number: 8,
            img: "CARD/225_08.jpg",
            meaning: "內在力量，勇氣，同理心，溫柔的力量。",
            interpretation: "用愛和耐心來面對挑戰，而不是暴力。"
        },
        {
            id: 9,
            name: "隱士",
            number: 9,
            img: "CARD/225_09.jpg",
            meaning: "內省，獨處，尋求智慧，自我反省。",
            interpretation: "需要一些獨處時間來思考和反省。"
        },
        {
            id: 10,
            name: "命運之輪",
            number: 10,
            img: "CARD/225_10.jpg",
            meaning: "命運，循環，變化，接受變化，把握機會。",
            interpretation: "生命正在轉變，接受改變並保持樂觀。"
        },
        {
            id: 11,
            name: "正義",
            number: 11,
            img: "CARD/225_11.jpg",
            meaning: "公平，平衡，真理，做出公平的決定。",
            interpretation: "需要做出公正的判斷，保持客觀。"
        },
        {
            id: 12,
            name: "懸吊",
            number: 12,
            img: "CARD/225_12.jpg",
            meaning: "犧牲，放下，新視角，暫停，轉換觀點。",
            interpretation: "需要改變視角，或暫時放下某些事物。"
        },
        {
            id: 13,
            name: "死神",
            number: 13,
            img: "CARD/225_13.jpg",
            meaning: "轉變，結束，新開始，結束舊循環。",
            interpretation: "某個階段即將結束，準備迎接新的開始。"
        },
        {
            id: 14,
            name: "節制",
            number: 14,
            img: "CARD/225_14.jpg",
            meaning: "平衡，和諧，適度，整合不同面向。",
            interpretation: "尋找生活中的平衡點，保持和諧。"
        },
        {
            id: 15,
            name: "惡魔",
            number: 15,
            img: "CARD/225_15.jpg",
            meaning: "束縛，誘惑，執著，面對內在的陰暗面。",
            interpretation: "需要面對並克服內在的恐懼和執著。"
        },
        {
            id: 16,
            name: "高塔",
            number: 16,
            img: "CARD/225_16.jpg",
            meaning: "突變，動盪，突破，��事件，打破舊有結構。",
            interpretation: "即將發生重大改變，雖然驚人但有助於成長。"
        },
        {
            id: 17,
            name: "星星",
            number: 17,
            img: "CARD/225_17.jpg",
            meaning: "希望，信心，治癒，相信夢想。",
            interpretation: "保持希望和信心，相信美好的事物即將發生。"
        },
        {
            id: 18,
            name: "月亮",
            number: 18,
            img: "CARD/225_18.jpg",
            meaning: "幻覺，恐懼，潛意識，面對恐懼。",
            interpretation: "需要面對內在的恐懼和不確定性。"
        },
        {
            id: 19,
            name: "太陽",
            number: 19,
            img: "CARD/225_19.jpg",
            meaning: "喜悅，成功，活力，享受成功。",
            interpretation: "充滿正能量的時期，享受生活帶來的快樂。"
        },
        {
            id: 20,
            name: "審判",
            number: 20,
            img: "CARD/225_20.jpg",
            meaning: "覺醒，重生，寬恕，反省過去。",
            interpretation: "是時候重新評估過去，並準備新的開始。"
        },
        {
            id: 21,
            name: "世界",
            number: 21,
            img: "CARD/225_21.jpg",
            meaning: "完成，圓滿，整體性，達到目標。",
            interpretation: "一個重要階段即將完成，感受圓滿。"
        }
    ],
    wands: [
        {
            id: 22,
            name: "權杖王牌",
            number: 1,
            img: "CARD/225_22.jpg",
            meaning: "新的開始，靈感，創造力，熱情。",
            interpretation: "新的機會即將到來，保持熱情和創造力。"
        },
        {
            id: 23,
            name: "權杖二",
            number: 2,
            img: "CARD/225_23.jpg",
            meaning: "規劃，進展，決策，展望未來。",
            interpretation: "是時候規劃未來，做出重要決定。"
        },
        {
            id: 24,
            name: "權杖三",
            number: 3,
            img: "CARD/225_24.jpg",
            meaning: "行動，進展，遠見，拓展視野。",
            interpretation: "計劃正在順利進展，保持前進的動力。"
        },
        {
            id: 25,
            name: "權杖四",
            number: 4,
            img: "CARD/225_25.jpg",
            meaning: "慶祝，和諧，穩定，家庭，歸屬感。",
            interpretation: "值得慶祝的時刻，享受�����果和穩定。"
        },
        {
            id: 26,
            name: "權杖五",
            number: 5,
            img: "CARD/225_26.jpg",
            meaning: "競爭，衝突，意見分歧，挑戰。",
            interpretation: "面臨競爭或衝突，需要妥善處理分歧。"
        },
        {
            id: 27,
            name: "權杖六",
            number: 6,
            img: "CARD/225_27.jpg",
            meaning: "勝利，成功，公眾認可，自信。",
            interpretation: "努力得到回報，享受成功的喜悅。"
        },
        {
            id: 28,
            name: "權杖七",
            number: 7,
            img: "CARD/225_28.jpg",
            meaning: "防禦，堅持立場，毅力。",
            interpretation: "堅持自己的立場，保持勇氣和決心。"
        },
        {
            id: 29,
            name: "權杖八",
            number: 8,
            img: "CARD/225_29.jpg",
            meaning: "快速行動，進展，消息，溝通。",
            interpretation: "事情正在快速發展，保持靈活應對。"
        },
        {
            id: 30,
            name: "權杖九",
            number: 9,
            img: "CARD/225_30.jpg",
            meaning: "韌性，堅持，最後一搏，堅韌不拔。",
            interpretation: "雖然疲憊但要堅持到底，勝利在望。"
        },
        {
            id: 31,
            name: "權杖十",
            number: 10,
            img: "CARD/225_31.jpg",
            meaning: "負擔，責任，過度工作，壓力。",
            interpretation: "需要學會分配工作，避免承擔過多。"
        },
        {
            id: 32,
            name: "權杖侍者",
            number: 11,
            img: "CARD/225_32.jpg",
            meaning: "新想法，探索，熱情，好奇心。",
            interpretation: "充滿熱情地探索新機會和想法。"
        },
        {
            id: 33,
            name: "權杖騎士",
            number: 12,
            img: "CARD/225_33.jpg",
            meaning: "行動導向，有野心，充滿熱情，追求冒險。",
            interpretation: "勇於追求目標，充滿行動力。"
        },
        {
            id: 34,
            name: "權杖皇后",
            number: 13,
            img: "CARD/225_34.jpg",
            meaning: "自信，獨立，熱情，勇敢，領導力。",
            interpretation: "展現自信和領導能力的時刻。"
        },
        {
            id: 35,
            name: "權杖國王",
            number: 14,
            img: "CARD/225_35.jpg",
            meaning: "領袖，遠見，企業家精神，充滿魅力。",
            interpretation: "以願景和魅力領導他人。"
        }
    ],
    cups: [
        {
            id: 36,
            name: "聖杯王牌",
            number: 1,
            img: "CARD/225_36.jpg",
            meaning: "愛，喜悅，情感滿足，新的關係，同理心。",
            interpretation: "新的感情機會，或情感上的突破。"
        },
        {
            id: 37,
            name: "聖杯二",
            number: 2,
            img: "CARD/225_37.jpg",
            meaning: "合作關係，連結，愛，和諧，互相吸引。",
            interpretation: "建立新的感情關係或加深現有連結。"
        },
        {
            id: 38,
            name: "聖杯三",
            number: 3,
            img: "CARD/225_38.jpg",
            meaning: "慶祝，友誼，社群，歡樂，團聚。",
            interpretation: "與朋友共度歡樂時光，享受社交活動。"
        },
        {
            id: 39,
            name: "聖杯四",
            number: 4,
            img: "CARD/225_39.jpg",
            meaning: "倦怠，無聊，不足，情緒���落，缺乏動力。",
            interpretation: "需要重新找回生活的熱情和動力。"
        },
        {
            id: 40,
            name: "聖杯五",
            number: 5,
            img: "CARD/225_40.jpg",
            meaning: "失落，悲傷，失望，感受傷。",
            interpretation: "面對失落，但要記得還有希望存在。"
        },
        {
            id: 41,
            name: "聖杯六",
            number: 6,
            img: "CARD/225_41.jpg",
            meaning: "懷舊，回憶，童年，純真，過去的影響。",
            interpretation: "從��去的美好回憶中汲取力量。"
        },
        {
            id: 42,
            name: "聖杯七",
            number: 7,
            img: "CARD/225_42.jpg",
            meaning: "選擇，幻想，白日夢，想像，選項。",
            interpretation: "面對多個選擇，需要實事求是。"
        },
        {
            id: 43,
            name: "聖杯八",
            number: 8,
            img: "CARD/225_43.jpg",
            meaning: "失望，放棄，離開，尋求更好的。",
            interpretation: "是時候放下不再適合的，尋找新的方向。"
        },
        {
            id: 44,
            name: "聖杯九",
            number: 9,
            img: "CARD/225_44.jpg",
            meaning: "願望實現，滿足，心想事成，滿足感。",
            interpretation: "願望即將實現，享受豐盛的成果。"
        },
        {
            id: 45,
            name: "聖杯十",
            number: 10,
            img: "CARD/225_45.jpg",
            meaning: "幸福，情感滿足，家庭和諧，圓滿。",
            interpretation: "達到情感和家庭生活的圓滿。"
        },
        {
            id: 46,
            name: "聖杯侍者",
            number: 11,
            img: "CARD/225_46.jpg",
            meaning: "創意，敏感，夢幻，浪漫，藝術天分。",
            interpretation: "保持對生活的浪漫想像和創意。"
        },
        {
            id: 47,
            name: "聖杯騎士",
            number: 12,
            img: "CARD/225_47.jpg",
            meaning: "浪漫，理想主義，魅力，感性。",
            interpretation: "追求理想的愛情或創意靈感。"
        },
        {
            id: 48,
            name: "聖杯皇后",
            number: 13,
            img: "CARD/225_48.jpg",
            meaning: "直覺，同理心，關愛，滋養，善解人意。",
            interpretation: "運用同理心和直覺來處理關係。"
        },
        {
            id: 49,
            name: "聖杯國王",
            number: 14,
            img: "CARD/225_49.jpg",
            meaning: "情感穩定，慈悲，圓融，智慧，成熟。",
            interpretation: "以成熟穩重的態度處理感情。"
        }
    ],
    swords: [
        {
            id: 50,
            name: "寶劍王牌",
            number: 1,
            img: "CARD/225_50.jpg",
            meaning: "新想法，突破，心智清晰，真理。",
            interpretation: "思維清晰的時刻，新的想法即將突破。"
        },
        {
            id: 51,
            name: "寶劍二",
            number: 2,
            img: "CARD/225_51.jpg",
            meaning: "僵局，猶豫不決，情感受阻。",
            interpretation: "需要做出決定，不要逃避現實。"
        },
        {
            id: 52,
            name: "寶劍三",
            number: 3,
            img: "CARD/225_52.jpg",
            meaning: "心碎，悲傷，失落，痛苦。",
            interpretation: "面對痛苦，讓時間治癒傷痛。"
        },
        {
            id: 53,
            name: "寶劍四",
            number: 4,
            img: "CARD/225_53.jpg",
            meaning: "休息，恢復，沉思，休養。",
            interpretation: "需要時間休息和恢復力量。"
        },
        {
            id: 54,
            name: "寶劍五",
            number: 5,
            img: "CARD/225_54.jpg",
            meaning: "衝突，失敗，背叛，挫折。",
            interpretation: "面對衝突和失敗，尋找解決方案。"
        },
        {
            id: 55,
            name: "寶劍六",
            number: 6,
            img: "CARD/225_55.jpg",
            meaning: "前進，過渡，放下過去，療癒。",
            interpretation: "是時候放下過去，���向新的階段。"
        },
        {
            id: 56,
            name: "寶劍七",
            number: 7,
            img: "CARD/225_56.jpg",
            meaning: "欺騙，偷竊，秘密行動，策略。",
            interpretation: "小心他人的欺騙，或反思自己的行為。"
        },
        {
            id: 57,
            name: "寶劍八",
            number: 8,
            img: "CARD/225_57.jpg",
            meaning: "受限，困境，自我設限，束縛。",
            interpretation: "打破自我設限，尋找出路。"
        },
        {
            id: 58,
            name: "寶劍九",
            number: 9,
            img: "CARD/225_58.jpg",
            meaning: "焦慮，憂慮，噩夢，絕望。",
            interpretation: "不要被恐懼支配，保持希望。"
        },
        {
            id: 59,
            name: "寶劍十",
            number: 10,
            img: "CARD/225_59.jpg",
            meaning: "結束，失敗，痛苦的終結，谷底。",
            interpretation: "最黑暗的時刻已過，光明即將到來。"
        },
        {
            id: 60,
            name: "寶劍侍者",
            number: 11,
            img: "CARD/225_60.jpg",
            meaning: "好奇，警覺，觀察力，溝���。",
            interpretation: "保持警覺和好奇心，注意周圍訊息。"
        },
        {
            id: 61,
            name: "寶劍騎士",
            number: 12,
            img: "CARD/225_61.jpg",
            meaning: "行動力，野心，智慧，果斷。",
            interpretation: "果斷行動，追求目標。"
        },
        {
            id: 62,
            name: "寶劍皇后",
            number: 13,
            img: "CARD/225_62.jpg",
            meaning: "獨立，分析力，洞察力，清晰。",
            interpretation: "運用智慧和洞察力做出決定。"
        },
        {
            id: 63,
            name: "寶劍國王",
            number: 14,
            img: "CARD/225_63.jpg",
            meaning: "理智，邏輯，公正，權威。",
            interpretation: "以理性和公正的態度處理事情。"
        }
    ],
    pentacles: [
        {
            id: 64,
            name: "錢幣��牌",
            number: 1,
            img: "CARD/225_64.jpg",
            meaning: "新機會，繁榮，豐盛，實現。",
            interpretation: "物質或事業上的新機會即將出現。"
        },
        {
            id: 65,
            name: "錢幣二",
            number: 2,
            img: "CARD/225_65.jpg",
            meaning: "平衡多項任務，適應力，時間管理。",
            interpretation: "需要在多個責任之間找到平衡。"
        },
        {
            id: 66,
            name: "錢幣三",
            number: 3,
            img: "CARD/225_66.jpg",
            meaning: "團隊合作，技能發展，專業成長。",
            interpretation: "通過合作和學習來提升技能。"
        },
        {
            id: 67,
            name: "錢幣四",
            number: 4,
            img: "CARD/225_67.jpg",
            meaning: "安全感，控制，穩定，保守。",
            interpretation: "注意在安全與成長之間取得平衡。"
        },
        {
            id: 68,
            name: "錢幣五",
            number: 5,
            img: "CARD/225_68.jpg",
            meaning: "物質損失，困境，孤立，排除在外。",
            interpretation: "暫時的困難將帶來���大的學習���"
        },
        {
            id: 69,
            name: "錢幣六",
            number: 6,
            img: "CARD/225_69.jpg",
            meaning: "慷慨，給予與接受，互助。",
            interpretation: "分享財富和資源，建立互惠關係。"
        },
        {
            id: 70,
            name: "錢幣七",
            number: 7,
            img: "CARD/225_70.jpg",
            meaning: "耐心，毅力，長期投資，願景。",
            interpretation: "持續投入將帶來豐碩的成果。"
        },
        {
            id: 71,
            name: "錢幣八",
            number: 8,
            img: "CARD/225_71.jpg",
            meaning: "專注，技藝，精進，職業發展。",
            interpretation: "專注於技能提升和專業發展。"
        },
        {
            id: 72,
            name: "錢幣九",
            number: 9,
            img: "CARD/225_72.jpg",
            meaning: "獨立，成功，自給自足，成就。",
            interpretation: "享受獨立和成功帶來的滿足感。"
        },
        {
            id: 73,
            name: "錢幣十",
            number: 10,
            img: "CARD/225_73.jpg",
            meaning: "財富，家族傳承，物質安全，豐盛。",
            interpretation: "達到物質和家庭生活的豐盛圓滿。"
        },
        {
            id: 74,
            name: "錢幣侍者",
            number: 11,
            img: "CARD/225_74.jpg",
            meaning: "學習，實用，新技能，務實態度。",
            interpretation: "專注學習新技���，保持務實態度。"
        },
        {
            id: 75,
            name: "錢幣騎士",
            number: 12,
            img: "CARD/225_75.jpg",
            meaning: "可靠，勤奮，負責，專注。",
            interpretation: "以踏實的態度逐步實現目標。"
        },
        {
            id: 76,
            name: "錢幣皇后",
            number: 13,
            img: "CARD/225_76.jpg",
            meaning: "實際，富足，滋養，慷慨。",
            interpretation: "善用資源，創造豐盛的生活。"
        },
        {
            id: 77,
            name: "錢幣國王",
            number: 14,
            img: "CARD/225_77.jpg",
            meaning: "成功，富有，穩健，商業頭腦。",
            interpretation: "在事業和財務上展現領導能力。"
        }
    ]
};

class TarotReading {
    constructor() {
        this.deck = this.initializeDeck();
        this.selectedCards = [];
        this.spreadType = 'three';
        this.initializeUI();
        this.initializeLazyLoading();
        this.initializeErrorHandling();
    }

    initializeDeck() {
        // 創建完整牌組的副本
        let deck = [];
        
        // 添加所有牌組
        Object.values(tarotCards).forEach(suit => {
            deck = deck.concat([...suit]);
        });
        
        console.log('初始牌組數量:', deck.length); // 用於調試
        return this.shuffleDeck(deck);
    }

    shuffleDeck(deck) {
        let currentDeck = [...deck];
        let shuffledDeck = [];
        
        // Fisher-Yates 洗牌算法
        while (currentDeck.length > 0) {
            const randomIndex = Math.floor(Math.random() * currentDeck.length);
            shuffledDeck.push(currentDeck.splice(randomIndex, 1)[0]);
        }
        
        console.log('洗牌後數量:', shuffledDeck.length); // 用於調試
        return shuffledDeck;
    }

    // 切牌功能
    cutDeck() {
        const cutPoint = Math.floor(Math.random() * (this.deck.length - 1)) + 1;
        const top = this.deck.slice(0, cutPoint);
        const bottom = this.deck.slice(cutPoint);
        this.deck = [...bottom, ...top];
    }

    initializeUI() {
        // 獲取開始占卜按鈕（已經在 HTML 中）
        const startButton = document.getElementById('start-reading');
        startButton.addEventListener('click', () => this.startReading());

        // 添加牌陣選擇
        const spreadSelect = document.createElement('select');
        spreadSelect.id = 'spread-type';
        spreadSelect.innerHTML = `
            <option value="single">單張牌陣</option>
            <option value="three" selected>三張牌陣</option>
            <option value="celtic">凱爾特十字牌陣</option>
        `;
        spreadSelect.addEventListener('change', (e) => {
            this.spreadType = e.target.value;
        });
        startButton.insertAdjacentElement('beforebegin', spreadSelect);

        // 添加重置按鈕
        const resetButton = document.createElement('button');
        resetButton.id = 'reset-reading';
        resetButton.textContent = '重新開始';
        resetButton.style.marginLeft = '10px';
        resetButton.addEventListener('click', () => this.resetReading());
        startButton.insertAdjacentElement('afterend', resetButton);

        // 添加牌陣說明按鈕
        const helpButton = document.createElement('button');
        helpButton.id = 'help-button';
        helpButton.textContent = '牌陣說明';
        helpButton.style.marginLeft = '10px';
        helpButton.addEventListener('click', () => this.showSpreadHelp());
        resetButton.insertAdjacentElement('afterend', helpButton);

        // 添加問題建議
        const questionSuggestions = [
            "我的事業發展方向如何？",
            "我的感情狀況將如何發展？",
            "如何改善目前的人際關係？",
            "我該如何解決當前的困境？",
            "未來有什麼機會和挑戰？"
        ];
        
        const suggestionList = document.createElement('div');
        suggestionList.className = 'question-suggestions';
        suggestionList.innerHTML = `
            <p>建議問題：</p>
            ${questionSuggestions.map(q => 
                `<button class="suggestion-btn">${q}</button>`
            ).join('')}
        `;
        
        document.querySelector('.question-section').appendChild(suggestionList);
        
        // 點擊建議問題
        suggestionList.addEventListener('click', (e) => {
            if (e.target.classList.contains('suggestion-btn')) {
                document.querySelector('textarea').value = e.target.textContent;
            }
        });
    }

    startReading() {
        const questionText = document.querySelector('textarea').value;
        if (!questionText.trim()) {
            alert('請先輸入你的問題！');
            return;
        }

        // 清空之前的結果
        document.getElementById('result').innerHTML = '';
        this.selectedCards = [];
        
        // 洗牌和切牌
        this.deck = this.shuffleDeck(this.deck);
        this.cutDeck();

        const cardCount = {
            'single': 1,
            'three': 3,
            'celtic': 10
        }[this.spreadType];

        const cardDeck = document.getElementById('card-deck');
        cardDeck.innerHTML = '';
        
        // 設置牌陣類型的類名
        if (this.spreadType === 'celtic') {
            cardDeck.className = 'celtic-cross';
        } else {
            cardDeck.className = 'linear-spread';
        }
        
        // 創建牌陣並添加發牌動畫
        for (let i = 0; i < cardCount; i++) {
            const card = document.createElement('div');
            card.className = 'card dealing';
            if (this.spreadType === 'celtic') {
                card.classList.add(`position-${i}`);
            }
            card.innerHTML = '<img src="CARD/225_78.jpg" alt="牌背">';
            
            // 設置延遲發牌和自動翻牌
            setTimeout(() => {
                cardDeck.appendChild(card);
                setTimeout(() => {
                    card.classList.remove('dealing');
                    // 發完牌後自動翻開
                    setTimeout(() => {
                        this.autoDrawCard(card, i);
                    }, 1000 + i * 500); // 每張牌間隔 0.5 秒翻開
                }, 50);
            }, i * 300);
        }
    }

    // 新增自動翻牌方法
    autoDrawCard(cardElement, position) {
        const card = this.deck.pop();
        this.selectedCards.push(card);
        cardElement.classList.add('drawn');
        cardElement.classList.add('flipping');
        
        setTimeout(() => {
            this.displayCard(card, cardElement, position);
            cardElement.classList.remove('flipping');
        }, 400);
    }

    displayCard(card, cardElement, position) {
        // 使用延遲載入屬性
        cardElement.innerHTML = `<img data-src="${card.img}" alt="${card.name}" src="CARD/225_78.jpg">`;
        
        // 顯示解讀
        const resultDiv = document.getElementById('result');
        const cardResult = document.createElement('div');
        cardResult.className = 'card-result';

        // 根據牌陣類型和位置顯示不同的解讀
        let positionMeaning = '';
        if (this.spreadType === 'three') {
            positionMeaning = [
                '過去的影響',
                '當前的情況',
                '未來的發展'
            ][position];
        } else if (this.spreadType === 'celtic') {
            positionMeaning = [
                '當前情況',
                '面臨的挑戰',
                '過去基礎',
                '即將過去',
                '最高期望',
                '即將到來',
                '自我態度',
                '環境影響',
                '希望與恐懼',
                '最終結果'
            ][position];
        }

        cardResult.innerHTML = `
            <h3>${positionMeaning ? `${positionMeaning}：` : ''}${card.name}</h3>
            <img src="${card.img}" alt="${card.name}">
            <p class="meaning">${card.meaning}</p>
            <p class="interpretation">${card.interpretation}</p>
        `;

        // 根據位置插入結果
        if (position === 0) {
            resultDiv.innerHTML = ''; // 清空之前的結果
        }
        resultDiv.appendChild(cardResult);

        // 如果是凱爾特十字牌陣，調整卡牌位置
        if (this.spreadType === 'celtic') {
            cardElement.style.gridArea = `pos${position + 1}`;
        }
    }

    resetReading() {
        this.deck = this.initializeDeck();
        this.selectedCards = [];
        document.getElementById('result').innerHTML = '';
        document.getElementById('card-deck').innerHTML = '';
        document.querySelector('textarea').value = '';
    }

    showSpreadHelp() {
        const helpText = {
            'single': '單張牌陣：最基本的牌陣，適合回答簡單的是非問題。',
            'three': '三張牌陣：分別代表過去、現在和未來，可以了解事情的發展脈絡。',
            'celtic': '凱爾特十字牌陣：最完整的牌陣，可以深入分析問題的各個面向。\n\n' +
                     '1. 當前情況：代表問題的核心\n' +
                     '2. 面臨的挑戰：當前的阻礙\n' +
                     '3. 過去基礎：問題的根源\n' +
                     '4. 即將過去：正在消退的影響\n' +
                     '5. 最高期望：可能達的最佳結果\n' +
                     '6. 即將到來：未來的發展\n' +
                     '7. 自我態度：你對問題的看法\n' +
                     '8. 環境影響：外在環境的影響\n' +
                     '9. 希望與恐懼：內心的期待和擔憂\n' +
                     '10. 最終結果：最可能的結果'
        };

        alert(helpText[this.spreadType]);
    }

    initializeLazyLoading() {
        // 使用 Intersection Observer 實現圖片延遲載入
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    observer.unobserve(img);
                }
            });
        });

        // 監視所有卡牌圖片
        document.querySelectorAll('img[data-src]').forEach(img => {
            observer.observe(img);
        });
    }

    initializeErrorHandling() {
        window.addEventListener('error', (event) => {
            console.error('應用錯誤:', event.error);
            this.recoverFromError();
        });
    }

    recoverFromError() {
        // 重置應用狀態
        this.resetReading();
        // 顯示友好的錯誤訊息
        alert('發生了一些問題，已重置應用。請重試。');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new TarotReading();
}); 